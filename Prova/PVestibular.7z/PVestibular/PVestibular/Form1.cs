﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PVestibular
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void BtnEntradaDeDados_Click(object sender, EventArgs e)
        {
            int numCurso = 4;
            int numAno = 4;
            int numAlunos = 4;
            int[,] matriz = new int[numCurso, numAno];
            int[] totalCurso = new int[numAlunos];
            string auxiliar = "";

            for (int i = 0; i < numCurso; i++)
            {
                totalCurso[i] = 0;
                for (int j = 0; j < numAno; j++)
                {
                    auxiliar = Interaction.InputBox("Total do curso " + (i + 1) + "  Ano " + (j + 1) + ":", "Matriz de Cursos e Anos");
                    if (auxiliar == "")
                    {
                        return;
                    }
                    if (!int.TryParse(auxiliar, out matriz[i, j]))
                    {
                        MessageBox.Show("Número inválido");
                    }
                    totalCurso[i] += matriz[i,j];
                }
            }
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j<4; j++)
                {
                    lsbResultados.Items.Add("Total do curso " + (i + 1) + " Ano " + (j + 1) + ": " + matriz[i, j]);
                }
                lsbResultados.Items.Add(">>Total curso: " + totalCurso[i]);
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            //limpar a ListBox
        }
    }
}
