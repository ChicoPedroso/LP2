﻿namespace PVestibular
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEntradaDeDados = new System.Windows.Forms.Button();
            this.lsbResultados = new System.Windows.Forms.ListBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnEntradaDeDados
            // 
            this.btnEntradaDeDados.Location = new System.Drawing.Point(120, 86);
            this.btnEntradaDeDados.Name = "btnEntradaDeDados";
            this.btnEntradaDeDados.Size = new System.Drawing.Size(180, 65);
            this.btnEntradaDeDados.TabIndex = 0;
            this.btnEntradaDeDados.Text = "Receber Dados";
            this.btnEntradaDeDados.UseVisualStyleBackColor = true;
            this.btnEntradaDeDados.Click += new System.EventHandler(this.BtnEntradaDeDados_Click);
            // 
            // lsbResultados
            // 
            this.lsbResultados.FormattingEnabled = true;
            this.lsbResultados.ItemHeight = 20;
            this.lsbResultados.Location = new System.Drawing.Point(481, 86);
            this.lsbResultados.Name = "lsbResultados";
            this.lsbResultados.Size = new System.Drawing.Size(288, 344);
            this.lsbResultados.TabIndex = 1;
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(120, 225);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(180, 65);
            this.btnLimpar.TabIndex = 2;
            this.btnLimpar.Text = "limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.lsbResultados);
            this.Controls.Add(this.btnEntradaDeDados);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnEntradaDeDados;
        private System.Windows.Forms.ListBox lsbResultados;
        private System.Windows.Forms.Button btnLimpar;
    }
}

